-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asset_profile`
--

DROP TABLE IF EXISTS `asset_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_profile` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `assetTypeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_7024eed6097fee4ebe97acebc2` (`alias`),
  KEY `FK_7051a0a8061a458583aa916f8c2` (`createdById`),
  KEY `FK_a25497df74d73025b2356eb20c2` (`updatedById`),
  KEY `FK_637f920bafa21df6fee06318d2d` (`assetTypeId`),
  CONSTRAINT `FK_637f920bafa21df6fee06318d2d` FOREIGN KEY (`assetTypeId`) REFERENCES `asset_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_7051a0a8061a458583aa916f8c2` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_a25497df74d73025b2356eb20c2` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_profile`
--

LOCK TABLES `asset_profile` WRITE;
/*!40000 ALTER TABLE `asset_profile` DISABLE KEYS */;
INSERT INTO `asset_profile` VALUES ('08d80868-bc4a-481f-af25-9fbd44680b92','2020-03-02 14:06:32.557812','2020-03-27 14:32:11.000000',1,1,'Conveyor_Asset_Profile_1','Conveyor_Asset_Profile_1','Conveyor_Asset_Profile_1','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','a36fcd30-265d-4618-a98c-3d2a2d3bb021'),('219645b7-253a-4c08-900d-b0e3ed19b5d8','2020-03-30 06:47:59.775699','2020-03-30 06:48:11.000000',1,1,'Driller_Asset_Profile_2','Driller_Asset_Profile_2','Driller_Asset_Profile_2','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','c3e509af-b4a2-4cc1-9d3a-3c3381629c81'),('5622b977-eb67-4007-8dd7-182e2d5500da','2020-03-11 07:01:30.348003','2020-03-27 08:50:56.000000',1,1,'drups-004','drups-004','not right not implemented from fd','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','afd14f4f-895c-4ab8-96d8-f80eab966a0c'),('a5b69527-cc28-4757-b702-1a4f34987b66','2020-03-02 13:44:46.181384','2020-03-07 08:02:13.000000',1,0,'Induction_Asset_Profile_3','Induction_Asset_Profile_3','Induction_Asset_Profile_3','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','681a5144-630a-4455-b6b0-7226c3473d32'),('ac805bfa-4d8e-4e60-b72e-8fe178cbaf5a','2020-03-27 16:57:26.722747','2020-03-27 16:57:34.000000',1,1,'Boiler_Asset_Profile_4','Boiler_Asset_Profile_4','Boiler_Asset_Profile_4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','a36fcd30-265d-4618-a98c-3d2a2d3bb021');
/*!40000 ALTER TABLE `asset_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:43:24
