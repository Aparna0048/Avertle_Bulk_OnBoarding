-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asset_type`
--

DROP TABLE IF EXISTS `asset_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_type` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_e20d540b0db196665bc13a261c` (`alias`),
  KEY `FK_54430f1e74cc076e15e6d6bc94b` (`createdById`),
  KEY `FK_231a6b44f9c80f917cedd6320b9` (`updatedById`),
  CONSTRAINT `FK_231a6b44f9c80f917cedd6320b9` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_54430f1e74cc076e15e6d6bc94b` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_type`
--

LOCK TABLES `asset_type` WRITE;
/*!40000 ALTER TABLE `asset_type` DISABLE KEYS */;
INSERT INTO `asset_type` VALUES ('02676f76-0a80-48c7-822b-362843e27ccc','2020-03-05 05:59:33.217713','2020-03-05 05:59:33.217713',1,0,'droplifts','droplifts','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('681a5144-630a-4455-b6b0-7226c3473d32','2020-03-02 13:32:08.897897','2020-03-02 13:32:08.897897',1,0,'induction motor','induction motor','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('a36fcd30-265d-4618-a98c-3d2a2d3bb021','2020-03-02 14:05:03.072189','2020-03-02 14:05:03.072189',1,0,'conveyor','conveyor','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('afd14f4f-895c-4ab8-96d8-f80eab966a0c','2020-03-05 05:58:58.651004','2020-03-05 05:58:58.651004',1,0,'drups','drups','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('bd6240ef-0029-47ad-a90c-d5a788a9620d','2020-03-05 05:58:16.699682','2020-03-05 05:58:16.699682',1,0,'dc motor','dc motor','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('bfd49584-e6dc-41bd-8e7c-91988d7c4ea2','2020-03-05 06:00:11.752239','2020-03-05 06:00:11.752239',1,0,'rotating motors','rotating motors','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('c3e509af-b4a2-4cc1-9d3a-3c3381629c81','2020-03-05 05:58:33.134086','2020-03-05 05:58:33.134086',1,0,'alternator','alternator','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL);
/*!40000 ALTER TABLE `asset_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:43:06
