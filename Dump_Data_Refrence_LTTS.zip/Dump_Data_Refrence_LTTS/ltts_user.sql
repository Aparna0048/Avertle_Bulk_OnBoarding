-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `companyLevel` varchar(255) DEFAULT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `roleId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_e12875dfb3b1d92d7d7c5377e2` (`email`),
  KEY `FK_45c0d39d1f9ceeb56942db93cc5` (`createdById`),
  KEY `FK_db5173f7d27aa8a98a9fe6113df` (`updatedById`),
  KEY `FK_c28e52f758e7bbc53828db92194` (`roleId`),
  CONSTRAINT `FK_45c0d39d1f9ceeb56942db93cc5` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_c28e52f758e7bbc53828db92194` FOREIGN KEY (`roleId`) REFERENCES `role_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_db5173f7d27aa8a98a9fe6113df` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('2f2ce890-89a7-43b0-bb8a-30802b143e5b','2020-03-27 06:58:46.648940','2020-03-27 11:57:23.000000',1,1,'Aparna','Chudhari','aparna@gmail.com','$2a$10$EUhnnoieAsnUZJN4VAkZveH9hM8QUV03FTS35/P847bhCIk3B1G.K',NULL,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','6a81677b-8488-4bde-be07-0297333daa2b'),('74969ff6-d686-406e-9218-0317439f1272','2020-03-27 12:36:16.668499','2020-03-27 12:37:19.000000',1,1,'pooja ','singh','pooja123@gmail.com','$2a$10$jy3WFUwY5lk7PkQa3IPHde4OrezUqFCkdT8AniCbaXmAv4bX/dHrS',NULL,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','6a81677b-8488-4bde-be07-0297333daa2b'),('8580290c-4827-47c8-a920-2051f052fcd0','2020-03-27 12:37:05.705470','2020-03-27 12:37:05.705470',1,0,'aparna','chodhry','aparna1@gmail.com','$2a$10$r9G54lT2Ye0AnmnB3pD0/OzFTLQHKJsSeAOFV0gxdbpEkaz9NKUTe',NULL,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'6a81677b-8488-4bde-be07-0297333daa2b'),('8db0811d-aa56-4246-8a6d-91898f3bdbb3','2020-03-27 12:31:12.084549','2020-03-27 12:31:35.000000',1,1,'pooja','singh','pooja@gmail.com','$2a$10$955p52nfpIBwtPZhr87nBOUqzKXAepbsBNrl8P4ojBR2J69bp5GNy',NULL,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','6a81677b-8488-4bde-be07-0297333daa2b'),('993c5aaf-53fb-41b7-abd0-b717939dcf7b','2020-03-07 10:00:45.645737','2020-03-27 12:26:20.000000',1,1,'Usman','Bro','uzibro@gmail.com','$2a$10$v05yKAoXvvgnRdNv3eOcLuqDQ/VLrojOcE9h0WaJ6uCN0P/6iCxN2',NULL,'ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','6a81677b-8488-4bde-be07-0297333daa2b'),('ad2081e0-c1ce-4d70-a653-9328455392f4','2020-02-28 07:23:40.731094','2020-03-27 12:23:35.000000',1,0,'superadmin','ltts','test@gmail.com','$2a$10$TgySdpp4AvY8jprjlAiFd.pW.pkRl6ZU3p8whr8f7w2NHEAdvYG.i',NULL,NULL,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','6a81677b-8488-4bde-be07-0297333daa2b'),('b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','2020-03-20 13:15:47.420778','2020-03-20 13:15:47.420778',1,0,'darshan',NULL,'darshan@gmail.com','$2a$10$1fqxUxXMrEoPM24yY6hd1uiSzt5zX53kEo9ldd9DkCxzyKrsa0EoC',NULL,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'6a81677b-8488-4bde-be07-0297333daa2b'),('ee52297f-639a-4ea0-a78a-685e437566b8','2020-03-30 06:45:17.827059','2020-03-30 06:45:26.000000',1,1,'cxcxcxc','cxcxcxc','aparnavdfdf1@gmail.com','$2a$10$AqWyzfJhzJSL3M6Bj0bQ.eHABzayC/ZupLpmWaoZmTCp3LMdMJIAa',NULL,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','6a81677b-8488-4bde-be07-0297333daa2b');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:42:57
