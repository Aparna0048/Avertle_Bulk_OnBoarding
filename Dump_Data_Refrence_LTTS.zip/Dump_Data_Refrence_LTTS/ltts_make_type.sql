-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `make_type`
--

DROP TABLE IF EXISTS `make_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `make_type` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_7b60a850f0e097c152b8a1830f` (`alias`),
  KEY `FK_1d3748e955a43478cac1d3c3c75` (`createdById`),
  KEY `FK_2e0a498890b4b4b2b1014c92a81` (`updatedById`),
  CONSTRAINT `FK_1d3748e955a43478cac1d3c3c75` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_2e0a498890b4b4b2b1014c92a81` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `make_type`
--

LOCK TABLES `make_type` WRITE;
/*!40000 ALTER TABLE `make_type` DISABLE KEYS */;
INSERT INTO `make_type` VALUES ('67e2f703-9aec-4b23-9980-f2ae7d8f1b4e','2020-03-23 12:09:06.460685','2020-03-23 12:09:06.460685',1,0,'asset','asset','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('964355e3-cfdf-44da-aea8-98d82dfa6bd0','2020-03-23 12:08:39.562559','2020-03-23 12:08:39.562559',1,0,'sensor','sensor','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('96a2d8bc-4337-41f8-93c8-c7de31b83c29','2020-03-23 12:08:54.309236','2020-03-23 12:08:54.309236',1,0,'gateway','gateway','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('982f68fc-9e63-491e-b96e-b0146d4e7996','2020-03-23 12:09:22.912077','2020-03-23 12:09:22.912077',1,0,'subcomponent','subcomponent','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL);
/*!40000 ALTER TABLE `make_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:38:14
