-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client_level`
--

DROP TABLE IF EXISTS `client_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_level` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `level` int(11) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `clientId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_76ade027f81de6d4037555457e` (`alias`),
  UNIQUE KEY `IDX_f2b9c396caec439718c6f08f9d` (`level`),
  KEY `FK_8eaa4074b29906662fb4c8a1f53` (`createdById`),
  KEY `FK_0b43d130eec1b68e1d9c1444947` (`updatedById`),
  KEY `FK_8e422b14556810d28326f8257cb` (`clientId`),
  CONSTRAINT `FK_0b43d130eec1b68e1d9c1444947` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_8e422b14556810d28326f8257cb` FOREIGN KEY (`clientId`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_8eaa4074b29906662fb4c8a1f53` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_level`
--

LOCK TABLES `client_level` WRITE;
/*!40000 ALTER TABLE `client_level` DISABLE KEYS */;
INSERT INTO `client_level` VALUES ('30e6b9f9-693e-4c14-8998-59f1d91e03a7','2020-03-16 09:28:43.327961','2020-03-16 09:28:43.327961',1,0,'section details','section details',3,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'7a6bf2d0-0b54-4c77-87b9-7eca34c5ee3f'),('b3d00f84-a602-4785-9efb-54d4b1f75f97','2020-03-16 09:22:11.810819','2020-03-16 09:22:11.810819',1,0,'plant details','plant details',1,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'7a6bf2d0-0b54-4c77-87b9-7eca34c5ee3f'),('ffacbac2-9f77-437b-90cc-7dc77b08824a','2020-03-16 09:26:32.765166','2020-03-16 09:26:32.765166',1,0,'line details','line details',2,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'7a6bf2d0-0b54-4c77-87b9-7eca34c5ee3f');
/*!40000 ALTER TABLE `client_level` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:40:21
