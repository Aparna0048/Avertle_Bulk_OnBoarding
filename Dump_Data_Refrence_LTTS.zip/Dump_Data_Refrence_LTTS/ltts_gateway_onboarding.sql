-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gateway_onboarding`
--

DROP TABLE IF EXISTS `gateway_onboarding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gateway_onboarding` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `serialNo` varchar(255) NOT NULL,
  `mgfDate` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `gatewayProfileId` varchar(36) DEFAULT NULL,
  `makeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_c41a4e0316a7844b12ad7658f3` (`alias`),
  UNIQUE KEY `IDX_6bfc04b9a01b689d10600ee956` (`serialNo`),
  KEY `FK_58991b66f85feebca2c518c088b` (`createdById`),
  KEY `FK_be291b96ea598c287f9e6e3acc9` (`updatedById`),
  KEY `FK_50b350cedc83c966deecc43d695` (`gatewayProfileId`),
  KEY `FK_e0525fd4d162bc20e98a8ad5e90` (`makeId`),
  CONSTRAINT `FK_50b350cedc83c966deecc43d695` FOREIGN KEY (`gatewayProfileId`) REFERENCES `gateway_profile` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_58991b66f85feebca2c518c088b` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_be291b96ea598c287f9e6e3acc9` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_e0525fd4d162bc20e98a8ad5e90` FOREIGN KEY (`makeId`) REFERENCES `make` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_onboarding`
--

LOCK TABLES `gateway_onboarding` WRITE;
/*!40000 ALTER TABLE `gateway_onboarding` DISABLE KEYS */;
INSERT INTO `gateway_onboarding` VALUES ('0495e781-2923-4f83-96bf-5292868458e4','2020-03-26 09:13:16.829998','2020-03-30 05:41:35.000000',1,0,'gateway_onboard_5','gateway_onboard_5','gateway_onboard_5','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','000f5117-ac8f-458d-b703-0370b111fe09','3fec10de-5293-4c28-9cb4-350f27bc7bdf'),('4536c0d0-c7bc-4c8d-836d-5178c244d81b','2020-03-02 13:47:18.184350','2020-03-02 13:47:18.184350',1,0,'gateway_onboard_1','gateway_onboard_1','GATEWAY_ONBOARD_1','02/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'000f5117-ac8f-458d-b703-0370b111fe09','3fec10de-5293-4c28-9cb4-350f27bc7bdf'),('4ddb77d3-2f6f-4c0b-ba8f-f581f5fd9281','2020-03-27 17:31:13.033334','2020-03-27 17:31:22.000000',1,1,'gateway_onboard_4','gateway_onboard_4','gateway_onboard_4','27/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','711f5f91-491d-4436-be75-ac7f4f251b2a','3fec10de-5293-4c28-9cb4-350f27bc7bdf'),('5ba817bb-eece-41e8-af89-fdf3a6f7b041','2020-03-05 13:05:55.182212','2020-03-09 10:01:52.000000',1,0,'gateway_onboard_3','gateway_onboard_3','GATEWAY_ONBOARD_3','05/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','b3e00453-2605-4e7c-8bed-10aac2f179da','3fec10de-5293-4c28-9cb4-350f27bc7bdf'),('6f3148a9-feb5-4e43-b376-bdebfe2e6070','2020-03-02 14:08:33.441733','2020-03-07 07:43:15.000000',1,0,'gateway_onboard_2','gateway_onboard_2','GATEWAY_ONBOARD_2','02/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','711f5f91-491d-4436-be75-ac7f4f251b2a','3fec10de-5293-4c28-9cb4-350f27bc7bdf'),('d34704de-1cea-4441-b6d7-e780fed3dd6b','2020-03-24 05:59:08.855396','2020-03-24 05:59:08.855396',1,0,'temperature-gateway','temperature-gateway','GATEWAYONBOARD-1','24/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'000f5117-ac8f-458d-b703-0370b111fe09','3fec10de-5293-4c28-9cb4-350f27bc7bdf');
/*!40000 ALTER TABLE `gateway_onboarding` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:42:31
