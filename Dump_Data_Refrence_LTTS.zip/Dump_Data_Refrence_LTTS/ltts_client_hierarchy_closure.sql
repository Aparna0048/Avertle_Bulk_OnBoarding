-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client_hierarchy_closure`
--

DROP TABLE IF EXISTS `client_hierarchy_closure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_hierarchy_closure` (
  `id_ancestor` varchar(255) NOT NULL,
  `id_descendant` varchar(255) NOT NULL,
  PRIMARY KEY (`id_ancestor`,`id_descendant`),
  KEY `IDX_bbf80645f834226d9fdbaf932a` (`id_ancestor`),
  KEY `IDX_7686063e91e254764e628f0f86` (`id_descendant`),
  CONSTRAINT `FK_7686063e91e254764e628f0f86d` FOREIGN KEY (`id_descendant`) REFERENCES `client_hierarchy` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_bbf80645f834226d9fdbaf932a9` FOREIGN KEY (`id_ancestor`) REFERENCES `client_hierarchy` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_hierarchy_closure`
--

LOCK TABLES `client_hierarchy_closure` WRITE;
/*!40000 ALTER TABLE `client_hierarchy_closure` DISABLE KEYS */;
INSERT INTO `client_hierarchy_closure` VALUES ('224c163a-a772-4fc1-9790-d59333404bdb','224c163a-a772-4fc1-9790-d59333404bdb'),('3bd4de79-46a3-4d58-89e6-f06deb925d5c','3bd4de79-46a3-4d58-89e6-f06deb925d5c'),('4d49f1b7-f9db-4da8-875e-268739af8d1f','4d49f1b7-f9db-4da8-875e-268739af8d1f'),('4e705cbc-da58-45ec-a8f2-e3310df0e57a','4e705cbc-da58-45ec-a8f2-e3310df0e57a'),('5e9ed54f-ee2f-41ce-a5e7-3f16344e0a18','5e9ed54f-ee2f-41ce-a5e7-3f16344e0a18'),('6f1f9b67-94a9-4d00-8924-fab12691fb92','6f1f9b67-94a9-4d00-8924-fab12691fb92'),('7a93c9cf-b596-4fa3-8113-2217021dc6ef','7a93c9cf-b596-4fa3-8113-2217021dc6ef'),('bcdacc5b-1b6d-46ba-87e9-d40b82f16b52','bcdacc5b-1b6d-46ba-87e9-d40b82f16b52'),('eb399d50-659c-4fad-b8be-3d0b5edbf735','eb399d50-659c-4fad-b8be-3d0b5edbf735');
/*!40000 ALTER TABLE `client_hierarchy_closure` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:38:32
