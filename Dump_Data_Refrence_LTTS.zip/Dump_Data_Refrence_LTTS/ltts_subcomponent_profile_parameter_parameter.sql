-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subcomponent_profile_parameter_parameter`
--

DROP TABLE IF EXISTS `subcomponent_profile_parameter_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcomponent_profile_parameter_parameter` (
  `subcomponentProfileId` varchar(36) NOT NULL,
  `parameterId` varchar(36) NOT NULL,
  PRIMARY KEY (`subcomponentProfileId`,`parameterId`),
  KEY `IDX_8b701f878908de6149102275ee` (`subcomponentProfileId`),
  KEY `IDX_66836bfabebb3fc56d72b9cd7c` (`parameterId`),
  CONSTRAINT `FK_66836bfabebb3fc56d72b9cd7c2` FOREIGN KEY (`parameterId`) REFERENCES `parameter` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `FK_8b701f878908de6149102275eee` FOREIGN KEY (`subcomponentProfileId`) REFERENCES `subcomponent_profile` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcomponent_profile_parameter_parameter`
--

LOCK TABLES `subcomponent_profile_parameter_parameter` WRITE;
/*!40000 ALTER TABLE `subcomponent_profile_parameter_parameter` DISABLE KEYS */;
INSERT INTO `subcomponent_profile_parameter_parameter` VALUES ('001a9c4e-3434-4e6f-b636-3980540fdcdc','2ec6fed6-41be-4ad3-9721-183f5e3d07af'),('3522c452-b118-412b-8211-cc11db23d313','b8a97076-7683-4b18-83f3-3f4a98d15c19'),('86415a8e-d754-4c76-8dd6-546d6b2b286e','b1f2a225-54cc-4def-9d2e-99300eb7d0c8'),('a716b80f-83de-4c61-8d3a-f8c6f77a4c1a','2ec6fed6-41be-4ad3-9721-183f5e3d07af'),('a716b80f-83de-4c61-8d3a-f8c6f77a4c1a','86de05d7-0376-4a8b-809e-93d0d57543b8'),('a716b80f-83de-4c61-8d3a-f8c6f77a4c1a','97d85d3b-4c4a-4669-ac80-c13670b58171'),('a716b80f-83de-4c61-8d3a-f8c6f77a4c1a','b8a97076-7683-4b18-83f3-3f4a98d15c19'),('a7c97e76-5626-4b83-b87e-155d306dcda8','2ec6fed6-41be-4ad3-9721-183f5e3d07af'),('dd8a503a-d822-4fc5-9292-3221506c9931','b8a97076-7683-4b18-83f3-3f4a98d15c19'),('ff604170-e79c-43c2-9e95-ea66216c2c8a','5c3fe937-6cbd-4bb7-a664-9c8bd9b24c9a');
/*!40000 ALTER TABLE `subcomponent_profile_parameter_parameter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:45:10
