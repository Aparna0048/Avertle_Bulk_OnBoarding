-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subcomponent_onboarding_additional_detail`
--

DROP TABLE IF EXISTS `subcomponent_onboarding_additional_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcomponent_onboarding_additional_detail` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `subcomponentProfileAdditionalInfoId` varchar(36) DEFAULT NULL,
  `gatewayOnboardingId` varchar(36) DEFAULT NULL,
  `gatewayOnboardingAdditionalDetailId` varchar(36) DEFAULT NULL,
  `subcomponentOnboardingId` varchar(36) DEFAULT NULL,
  `axisTypeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `REL_5c535d6f1ede865bd65b31d5a4` (`gatewayOnboardingAdditionalDetailId`),
  KEY `FK_ae4654033bacd5c6cdd5473c1c1` (`createdById`),
  KEY `FK_e5788c6adda3ae96658fa4099f5` (`updatedById`),
  KEY `FK_01a70535751860c74ab8c057ff0` (`subcomponentProfileAdditionalInfoId`),
  KEY `FK_f0efeb42e6ab1085c91fde3d25d` (`gatewayOnboardingId`),
  KEY `FK_a6f1bd015d2c7bf5a125e9666d3` (`subcomponentOnboardingId`),
  KEY `FK_c17ca16871ab275da2f5221f76f` (`axisTypeId`),
  CONSTRAINT `FK_01a70535751860c74ab8c057ff0` FOREIGN KEY (`subcomponentProfileAdditionalInfoId`) REFERENCES `subcomponent_profile_additional_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_5c535d6f1ede865bd65b31d5a46` FOREIGN KEY (`gatewayOnboardingAdditionalDetailId`) REFERENCES `gateway_onboarding_additional_detail` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_a6f1bd015d2c7bf5a125e9666d3` FOREIGN KEY (`subcomponentOnboardingId`) REFERENCES `subcomponent_onboarding` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ae4654033bacd5c6cdd5473c1c1` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_c17ca16871ab275da2f5221f76f` FOREIGN KEY (`axisTypeId`) REFERENCES `axis_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_e5788c6adda3ae96658fa4099f5` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_f0efeb42e6ab1085c91fde3d25d` FOREIGN KEY (`gatewayOnboardingId`) REFERENCES `gateway_onboarding` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcomponent_onboarding_additional_detail`
--

LOCK TABLES `subcomponent_onboarding_additional_detail` WRITE;
/*!40000 ALTER TABLE `subcomponent_onboarding_additional_detail` DISABLE KEYS */;
INSERT INTO `subcomponent_onboarding_additional_detail` VALUES ('123a12e5-1fa7-4d37-82ac-ac20f25a66ff','2020-03-09 10:35:56.351908','2020-03-26 09:15:08.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','f577e320-f141-4623-b60c-5b9e05b6acd2','5ba817bb-eece-41e8-af89-fdf3a6f7b041','cfed881b-8264-412a-85eb-dc351ff558b7','011e32dd-fec3-4847-8aeb-37e75ac3d113','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('3d509372-10cb-4171-9117-ac7e3e0be3f7','2020-03-26 08:52:37.468992','2020-03-26 09:14:55.000000',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','9ca4096f-1da1-4101-b293-93705868928d','d34704de-1cea-4441-b6d7-e780fed3dd6b','75b70ac4-69b1-494c-8890-a2755d623a30','f7a0c4f8-c95e-43d3-8149-96bd8a3038ea','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('40c32fde-75ea-4d67-87f7-28ce61b94263','2020-03-09 10:16:15.074988','2020-03-09 10:16:15.074988',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'76472f26-1b72-4687-8f5d-2605cc3421a8','5ba817bb-eece-41e8-af89-fdf3a6f7b041','f75a920d-f37d-4ae5-a3a1-ebaf360a814f','ba614ac2-6281-4a7c-a7ca-d3031c8be089','81d848dc-1333-4b9f-b944-5ebfd640d57a'),('4b40e97d-045e-44d9-b734-513561d99cb5','2020-03-12 10:43:32.305564','2020-03-12 10:43:32.305564',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'f577e320-f141-4623-b60c-5b9e05b6acd2','5ba817bb-eece-41e8-af89-fdf3a6f7b041','62d819d6-277f-457f-99be-7252147cbed8','ba6f547c-8e30-473f-8655-31c423a410d8','0fda8a75-4265-4385-9f9f-646c7e1b4ae9'),('a3541817-363b-4b6b-9d3e-c2e219ec923a','2020-03-02 13:48:26.185286','2020-03-07 07:46:30.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','f577e320-f141-4623-b60c-5b9e05b6acd2','4536c0d0-c7bc-4c8d-836d-5178c244d81b','8ecd992d-2aa1-4739-b3d9-d8a9c116cce9','74f74cdc-439e-40c6-a0ee-027553b57a81','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('a47353e6-40ef-418c-8480-1457c6c422ae','2020-03-26 09:14:21.785429','2020-03-26 09:14:21.785429',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'9ca4096f-1da1-4101-b293-93705868928d','0495e781-2923-4f83-96bf-5292868458e4','eb59690e-2dd8-41cd-8a16-fe1bed2152c7','c42d6e83-8e61-4891-ac2a-2d69bb438f25','f2cec923-1222-472c-9454-e1d68fdf7e14'),('a848d8bf-7d6c-4bf6-aca4-5027e779e32d','2020-03-05 13:11:26.298935','2020-03-07 07:46:04.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','242b22df-1ff8-4374-83ab-9c40e6f4ab05','5ba817bb-eece-41e8-af89-fdf3a6f7b041','7d22cfbd-cb29-4ae1-b2ab-056ed5801373','6c784119-a27a-442e-8d8e-a14c4856ed7e','baf18457-a95c-4f80-b053-6adaccfd1cbf'),('b064588c-2501-4892-a732-5b85e0b11b76','2020-03-09 10:16:15.064902','2020-03-09 10:16:15.064902',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'3f6b5119-baf6-4cb0-b46a-b58a44d9056c','5ba817bb-eece-41e8-af89-fdf3a6f7b041','468bac87-0164-4d9d-bd41-7363d91c1090','ba614ac2-6281-4a7c-a7ca-d3031c8be089','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('be7c32e1-922a-4b12-9b07-dd78d1d0355e','2020-03-09 10:16:15.095632','2020-03-09 10:16:15.095632',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'7ec34b50-5b4a-4b6b-8d8b-acd08d3ae479','5ba817bb-eece-41e8-af89-fdf3a6f7b041','d5d75ce4-3016-499f-ba24-1367e40e36d2','ba614ac2-6281-4a7c-a7ca-d3031c8be089','737d1f2c-9628-4525-ae51-0ada94e6be35'),('c70a076b-411d-406b-935f-fe8fe4f87716','2020-03-05 13:12:23.195249','2020-03-07 07:45:37.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','242b22df-1ff8-4374-83ab-9c40e6f4ab05','5ba817bb-eece-41e8-af89-fdf3a6f7b041','a75cb031-5f9f-4681-a364-d0216e07fd45','0df304f4-f5f7-47d8-8178-6c643572a945','81d848dc-1333-4b9f-b944-5ebfd640d57a'),('dae35001-0757-4714-bc2f-c96eb719b7af','2020-03-02 14:09:04.804175','2020-03-07 07:44:54.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','242b22df-1ff8-4374-83ab-9c40e6f4ab05','6f3148a9-feb5-4e43-b376-bdebfe2e6070','6cb7e115-6409-4656-b212-1c22f15d5f95','34a82dd3-4c79-4da1-a629-d34e25234a6f','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('f2e39e32-69c7-4036-96ba-72e3f2e30a00','2020-03-09 10:16:15.069458','2020-03-09 10:16:15.069458',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'5a0939de-9175-4640-be8d-011abece960c','5ba817bb-eece-41e8-af89-fdf3a6f7b041','b93a1dc6-8cf6-4304-af6c-fb523b890bce','ba614ac2-6281-4a7c-a7ca-d3031c8be089','0fda8a75-4265-4385-9f9f-646c7e1b4ae9');
/*!40000 ALTER TABLE `subcomponent_onboarding_additional_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:44:00
