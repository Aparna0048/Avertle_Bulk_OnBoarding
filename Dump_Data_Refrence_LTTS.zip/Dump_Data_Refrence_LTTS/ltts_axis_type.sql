-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `axis_type`
--

DROP TABLE IF EXISTS `axis_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `axis_type` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_7692124364317b43e48ae8b38d` (`alias`),
  KEY `FK_bc1d537afafceff4c12e4130d07` (`createdById`),
  KEY `FK_bb26f78aa6bd7cf598d12296cbc` (`updatedById`),
  CONSTRAINT `FK_bb26f78aa6bd7cf598d12296cbc` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_bc1d537afafceff4c12e4130d07` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `axis_type`
--

LOCK TABLES `axis_type` WRITE;
/*!40000 ALTER TABLE `axis_type` DISABLE KEYS */;
INSERT INTO `axis_type` VALUES ('06bb8d8d-6d13-45c3-9a77-2b5d48838acf','2020-03-02 13:33:23.272604','2020-03-02 13:33:23.272604',1,0,'1-axis','1-axis','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('0fda8a75-4265-4385-9f9f-646c7e1b4ae9','2020-03-05 06:00:37.385515','2020-03-05 06:00:37.385515',1,0,'3-axis','3-axis','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('737d1f2c-9628-4525-ae51-0ada94e6be35','2020-03-05 06:01:14.432183','2020-03-05 06:01:14.432183',1,0,'y-axis','y-axis','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('81d848dc-1333-4b9f-b944-5ebfd640d57a','2020-03-05 06:00:56.727794','2020-03-05 06:00:56.727794',1,0,'x-axis','x-axis','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('baf18457-a95c-4f80-b053-6adaccfd1cbf','2020-03-05 06:01:28.617805','2020-03-05 06:01:28.617805',1,0,'z-axis','z-axis','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('f2cec923-1222-472c-9454-e1d68fdf7e14','2020-03-24 09:43:37.645442','2020-03-27 14:56:21.000000',1,1,'test-axis12','test-axis12','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc');
/*!40000 ALTER TABLE `axis_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:39:43
