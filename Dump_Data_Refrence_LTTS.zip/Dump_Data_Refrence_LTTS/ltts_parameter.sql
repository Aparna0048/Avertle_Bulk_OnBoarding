-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `parameter`
--

DROP TABLE IF EXISTS `parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parameter` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `isDirect` tinyint(4) NOT NULL DEFAULT '0',
  `minValue` varchar(255) NOT NULL DEFAULT '',
  `maxValue` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `unitId` varchar(36) DEFAULT NULL,
  `sensorTypeId` varchar(36) DEFAULT NULL,
  `parameterTypeId` varchar(36) DEFAULT NULL,
  `chartId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_c0bf88d3f878f4097d20883dcd` (`alias`),
  KEY `FK_cd7369492c2ff3ff0510f58f7bf` (`createdById`),
  KEY `FK_dff4dc5b724ff8a4a6433b8b12b` (`updatedById`),
  KEY `FK_5e4a8bbcad3a68aaf374a5717ee` (`unitId`),
  KEY `FK_78f2b258269f70ba04aed1d3688` (`sensorTypeId`),
  KEY `FK_bc6435e73fe1722449bd9032b79` (`parameterTypeId`),
  KEY `FK_9b327d38027dc0a63ddf3569797` (`chartId`),
  CONSTRAINT `FK_5e4a8bbcad3a68aaf374a5717ee` FOREIGN KEY (`unitId`) REFERENCES `unit` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_78f2b258269f70ba04aed1d3688` FOREIGN KEY (`sensorTypeId`) REFERENCES `sensor_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_9b327d38027dc0a63ddf3569797` FOREIGN KEY (`chartId`) REFERENCES `chart` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_bc6435e73fe1722449bd9032b79` FOREIGN KEY (`parameterTypeId`) REFERENCES `parameter_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_cd7369492c2ff3ff0510f58f7bf` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_dff4dc5b724ff8a4a6433b8b12b` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parameter`
--

LOCK TABLES `parameter` WRITE;
/*!40000 ALTER TABLE `parameter` DISABLE KEYS */;
INSERT INTO `parameter` VALUES ('0fd5eebf-74c8-4e5c-851a-9f9bb0cec875','2020-03-05 05:47:03.142528','2020-03-05 05:47:03.142528',1,0,'voltage - b phase','voltage - b phase',0,'0','220','Voltage - B Phase','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'f2f45a78-9f49-4c91-9a05-869d749dee36','7accf643-0d94-4676-b232-0b033e01c69f','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('127495d7-ecf8-46d2-8a36-b401084b8bdf','2020-03-05 05:45:55.192730','2020-03-05 05:45:55.192730',1,0,'voltage - r phase','voltage - r phase',0,'0','220','voltage - r phase','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'f2f45a78-9f49-4c91-9a05-869d749dee36','7accf643-0d94-4676-b232-0b033e01c69f','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('2ec6fed6-41be-4ad3-9721-183f5e3d07af','2020-03-07 10:07:53.340240','2020-03-07 10:07:53.340240',1,0,'speed parameter ','speed ',0,'0','100','Speed Parameter ','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'19f17a00-bd2b-4de5-9a6a-819f3479682f','7842b5a2-45a0-4ca9-b723-78ae46b050f6','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('37f85247-0de6-4793-8ccb-d7c31334636a','2020-03-05 05:41:15.108055','2020-03-05 05:41:37.000000',1,0,'ignition parameter','ignition ',0,'20','220','ignition parameter','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','8127d633-f101-4389-b9be-8682435fd721','6f6691f6-2f1a-4bee-a80a-1785226a239d','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('5c3fe937-6cbd-4bb7-a664-9c8bd9b24c9a','2020-03-02 14:04:08.816793','2020-03-02 14:04:08.816793',1,0,'voltage parameter','voltage',0,'0','100','Voltage Parameter','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'f2f45a78-9f49-4c91-9a05-869d749dee36','7accf643-0d94-4676-b232-0b033e01c69f','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('5dd67e70-7f8b-49cb-ba9f-9f2b7def48c8','2020-03-30 07:20:58.240506','2020-03-30 07:21:04.000000',1,1,'xcxcxcxc','xcxcxcxcx',0,'XCXCXCXCXCXCX','XCXCXCXC','CXCXCXC','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','19f17a00-bd2b-4de5-9a6a-819f3479682f','1f73c9cc-f196-4b01-9fa5-bdeb54fc060a','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('713200f9-6566-4809-9403-1bb4af4811b6','2020-03-05 05:47:45.722720','2020-03-05 05:47:45.722720',1,0,'rms voltage','rms voltage',0,'0','220','rms voltage','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'f2f45a78-9f49-4c91-9a05-869d749dee36','7accf643-0d94-4676-b232-0b033e01c69f','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('86de05d7-0376-4a8b-809e-93d0d57543b8','2020-03-05 05:49:23.093511','2020-03-05 05:49:23.093511',1,0,'fuel parameter','fuel ',0,'0','273','fuel parameter','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'8127d633-f101-4389-b9be-8682435fd721','6f6691f6-2f1a-4bee-a80a-1785226a239d','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('97d85d3b-4c4a-4669-ac80-c13670b58171','2020-03-05 05:50:43.193928','2020-03-05 05:50:43.193928',1,0,'current parameter','current ',0,'0','500','current parameter','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'ba662db6-cbee-4894-81a0-97e04cc07444','5f99800d-6d35-408d-a863-5aff811a3ce7','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('b1f2a225-54cc-4def-9d2e-99300eb7d0c8','2020-03-02 13:31:20.382444','2020-03-02 13:31:20.382444',1,0,'tempearture parameter','temperature ',0,'0','220','Temp','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'674dabca-ad4f-486e-9203-3aa3b939863b','31d85ed9-7217-43ca-96cb-7e2e8e113875','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('b50032d5-75a9-48b4-89a2-2a8df991a9d1','2020-03-05 05:45:00.370266','2020-03-05 05:45:00.370266',1,0,'displacement parameter','displacement',0,'0','200','displacement Parameter','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'b01ba086-12b6-437b-b593-7b428744f83d','1f73c9cc-f196-4b01-9fa5-bdeb54fc060a','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('b8a97076-7683-4b18-83f3-3f4a98d15c19','2020-03-05 05:53:01.547708','2020-03-05 05:53:01.547708',1,0,'velocity parameter','velocity ',0,'0','220','Velocity Parameter','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'19f17a00-bd2b-4de5-9a6a-819f3479682f','1f73c9cc-f196-4b01-9fa5-bdeb54fc060a','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('c2a36b11-1049-415b-a7ef-3d6cb006a462','2020-03-30 07:31:38.963345','2020-03-30 07:32:37.000000',1,0,'fdfdf','dfdfd',1,'cccxcxc','zczczczcz','ccczc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','19f17a00-bd2b-4de5-9a6a-819f3479682f','1f73c9cc-f196-4b01-9fa5-bdeb54fc060a','52a75760-54af-422a-9189-5f79b6e546f1',NULL),('c4cb55c9-6674-447c-81d6-946d60a5cc8d','2020-03-24 09:46:12.189292','2020-03-27 14:29:38.000000',1,1,'testing123','testing123',0,'100','200','testing pls ignore','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','1717b8c2-6ff8-4a3e-a355-663ba920e9b0','7842b5a2-45a0-4ca9-b723-78ae46b050f6','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('d3b69453-a806-40f6-8133-9e6484820eb8','2020-03-05 05:46:25.308738','2020-03-05 05:46:25.308738',1,0,'voltage - y phase','voltage - y phase',0,'0','220','Voltage - Y Phase','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'f2f45a78-9f49-4c91-9a05-869d749dee36','7accf643-0d94-4676-b232-0b033e01c69f','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL),('faaefcc3-59e4-427a-bbbe-14d4926bcbe3','2020-03-05 05:48:30.377062','2020-03-05 05:48:30.377062',1,0,'average voltage','average voltage',0,'0','220','average voltage','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'f2f45a78-9f49-4c91-9a05-869d749dee36','7accf643-0d94-4676-b232-0b033e01c69f','7b5468e1-9307-4e64-aa9a-03b4b989185d',NULL);
/*!40000 ALTER TABLE `parameter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:41:47
