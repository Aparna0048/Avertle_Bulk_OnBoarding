-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asset_profile_additional_info`
--

DROP TABLE IF EXISTS `asset_profile_additional_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_profile_additional_info` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `statusId` varchar(36) DEFAULT NULL,
  `sensorTypeId` varchar(36) DEFAULT NULL,
  `assetProfileId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_b2e83c0236b285bd74520de6e29` (`createdById`),
  KEY `FK_495265b1cfd8709e0fdcd5b0a6b` (`updatedById`),
  KEY `FK_eb95dc514cb350ec22f11e804c8` (`statusId`),
  KEY `FK_d04f6cd352ab4e95d287e298bb4` (`sensorTypeId`),
  KEY `FK_92f4b4dc8f39387652ff5ac6492` (`assetProfileId`),
  CONSTRAINT `FK_495265b1cfd8709e0fdcd5b0a6b` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_92f4b4dc8f39387652ff5ac6492` FOREIGN KEY (`assetProfileId`) REFERENCES `asset_profile` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_b2e83c0236b285bd74520de6e29` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_d04f6cd352ab4e95d287e298bb4` FOREIGN KEY (`sensorTypeId`) REFERENCES `sensor_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_eb95dc514cb350ec22f11e804c8` FOREIGN KEY (`statusId`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_profile_additional_info`
--

LOCK TABLES `asset_profile_additional_info` WRITE;
/*!40000 ALTER TABLE `asset_profile_additional_info` DISABLE KEYS */;
INSERT INTO `asset_profile_additional_info` VALUES ('342880b9-951a-4bce-b570-4ac49590623e','2020-03-11 07:01:30.393804','2020-03-11 07:01:30.393804',1,0,NULL,NULL,100,80,70,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'d0febf4c-3d5d-4ab9-b43a-10d256c0e69d','31d85ed9-7217-43ca-96cb-7e2e8e113875','5622b977-eb67-4007-8dd7-182e2d5500da'),('79e0e983-a5a3-4dc1-af99-128dbe7201d4','2020-03-27 16:57:26.748344','2020-03-27 16:57:26.748344',1,0,NULL,NULL,434,343,32,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'d0febf4c-3d5d-4ab9-b43a-10d256c0e69d','1f73c9cc-f196-4b01-9fa5-bdeb54fc060a','ac805bfa-4d8e-4e60-b72e-8fe178cbaf5a'),('80146cee-9e45-4394-8dc3-bdf581d47bca','2020-03-02 14:06:32.615748','2020-03-07 08:01:41.000000',1,0,NULL,NULL,900,1,1,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'d0febf4c-3d5d-4ab9-b43a-10d256c0e69d','7accf643-0d94-4676-b232-0b033e01c69f','08d80868-bc4a-481f-af25-9fbd44680b92'),('825cc38e-4921-4707-81aa-cd21637173f1','2020-03-30 06:47:59.783985','2020-03-30 06:47:59.783985',1,0,NULL,NULL,3232,323232,2323,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'d0febf4c-3d5d-4ab9-b43a-10d256c0e69d','09712a55-6763-4c75-b7b0-39197a84a17f','219645b7-253a-4c08-900d-b0e3ed19b5d8'),('af5eae99-ca60-446c-996d-9fa7a7887ff7','2020-03-02 13:44:46.205922','2020-03-07 08:02:13.000000',1,0,NULL,NULL,500,10,10,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'d0febf4c-3d5d-4ab9-b43a-10d256c0e69d','31d85ed9-7217-43ca-96cb-7e2e8e113875','a5b69527-cc28-4757-b702-1a4f34987b66');
/*!40000 ALTER TABLE `asset_profile_additional_info` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:41:21
