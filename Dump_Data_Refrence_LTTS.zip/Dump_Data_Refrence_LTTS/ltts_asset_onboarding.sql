-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asset_onboarding`
--

DROP TABLE IF EXISTS `asset_onboarding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_onboarding` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `serialNo` varchar(255) NOT NULL,
  `mgfDate` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `assetProfileId` varchar(36) DEFAULT NULL,
  `makeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_dbc5c090e5dd8d7a2625cfd399` (`alias`),
  UNIQUE KEY `IDX_e4ba1094e188a09ea97c2751c3` (`serialNo`),
  KEY `FK_086eb710b1540f64b61cc090c73` (`createdById`),
  KEY `FK_963aeae5d1060627410e1f9edba` (`updatedById`),
  KEY `FK_6913d04ccf64f515d3c9934c0d7` (`assetProfileId`),
  KEY `FK_be4cddba3f3bccea40fa978ec06` (`makeId`),
  CONSTRAINT `FK_086eb710b1540f64b61cc090c73` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_6913d04ccf64f515d3c9934c0d7` FOREIGN KEY (`assetProfileId`) REFERENCES `asset_profile` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_963aeae5d1060627410e1f9edba` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_be4cddba3f3bccea40fa978ec06` FOREIGN KEY (`makeId`) REFERENCES `make` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_onboarding`
--

LOCK TABLES `asset_onboarding` WRITE;
/*!40000 ALTER TABLE `asset_onboarding` DISABLE KEYS */;
INSERT INTO `asset_onboarding` VALUES ('20388726-b652-448d-bd79-fea8aa83bfdf','2020-03-02 14:09:36.891905','2020-03-26 13:25:46.000000',1,0,'induction_asset_onboard_1','induction_asset_onboard_1','Induction_Asset_Onboard_1','02/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','08d80868-bc4a-481f-af25-9fbd44680b92','488be755-528f-4b80-820c-bd3e0b30de08'),('230d38ae-a6d4-4efb-8c7d-906be52ca00a','2020-03-26 11:43:00.797773','2020-03-26 11:43:00.797773',1,0,'conveyor_asset_onboard','conveyor_asset_onboard','conveyor_asset_onboard','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'5622b977-eb67-4007-8dd7-182e2d5500da','71d2fe7f-5197-4b16-9bb8-eaab647b2913'),('3c1fba72-9703-4aff-ae99-33737be7c941','2020-03-26 12:42:48.498647','2020-03-26 13:24:23.000000',1,0,'vibrational_asset-onboard','vibrational_asset-onboard','vibrational_asset-onboard','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','08d80868-bc4a-481f-af25-9fbd44680b92','488be755-528f-4b80-820c-bd3e0b30de08'),('51d6ebae-9762-4a83-b1a1-a82060b07749','2020-03-12 07:49:34.644931','2020-03-26 13:24:16.000000',1,0,'alternator_asset_onboard_5','alternator_asset_onboard_5','alternator_asset_onboard_5','12/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','08d80868-bc4a-481f-af25-9fbd44680b92','488be755-528f-4b80-820c-bd3e0b30de08'),('768988a6-162f-42e9-a4d5-23138c385337','2020-03-26 08:56:48.530567','2020-03-26 13:26:06.000000',1,0,'driller_asset_onboard','driller_asset_onboard','driller_asset_onboard','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','08d80868-bc4a-481f-af25-9fbd44680b92','488be755-528f-4b80-820c-bd3e0b30de08'),('78e3f11e-eadb-4ef0-b6e5-194bc16399cf','2020-03-26 08:51:13.914215','2020-03-26 08:51:13.914215',1,0,'cooling_pump_asset_onboard','cooling_pump_asset_onboard','cooling_pump_asset_onboard','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'08d80868-bc4a-481f-af25-9fbd44680b92','71d2fe7f-5197-4b16-9bb8-eaab647b2913'),('7c8d2dd7-a720-4df8-bb17-3c1d13af1a07','2020-03-06 08:06:31.950880','2020-03-26 13:23:30.000000',1,0,'chiller_asset_onboard_3','chiller_asset_onboard_3','Chiller_Asset_Onboard_3','07/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','08d80868-bc4a-481f-af25-9fbd44680b92','488be755-528f-4b80-820c-bd3e0b30de08'),('7fb3478e-2f79-447d-b100-989f1ba6ddff','2020-03-26 13:20:36.237802','2020-03-26 13:26:15.000000',1,0,'steam_boiler_asset_onboard','steam_boiler_asset_onboard','steam_boiler_asset_onboard','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','08d80868-bc4a-481f-af25-9fbd44680b92','488be755-528f-4b80-820c-bd3e0b30de08'),('a86cf149-2a7d-45a3-8727-ea97d3b85ed5','2020-03-02 13:49:02.470508','2020-03-30 05:41:59.000000',1,0,'induction_asset-onboard_2','induction_asset-onboard_2','Induction_Asset-Onboard_2','02/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','a5b69527-cc28-4757-b702-1a4f34987b66','488be755-528f-4b80-820c-bd3e0b30de08'),('cfe0f31b-8c9f-4c31-a711-a2ff0a601476','2020-03-06 08:05:13.188456','2020-03-26 13:26:30.000000',1,0,'drup_asset_onboard_4','drup_asset_onboard_4','Drup_Asset_Onboard_4','06/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','08d80868-bc4a-481f-af25-9fbd44680b92','488be755-528f-4b80-820c-bd3e0b30de08'),('e232d85d-573e-4557-a5ae-45e2fb93d7c1','2020-03-26 11:36:10.143794','2020-03-26 11:36:10.143794',1,0,'condensor_asset_onboard','condensor_asset_onboard','condensor_asset_onboard','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'08d80868-bc4a-481f-af25-9fbd44680b92','3fec10de-5293-4c28-9cb4-350f27bc7bdf');
/*!40000 ALTER TABLE `asset_onboarding` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:40:53
