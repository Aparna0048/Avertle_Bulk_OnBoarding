-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client_level_prop`
--

DROP TABLE IF EXISTS `client_level_prop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_level_prop` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `placeHolder` varchar(255) DEFAULT NULL,
  `isRequired` tinyint(4) NOT NULL DEFAULT '0',
  `validationPattern` varchar(255) DEFAULT NULL,
  `isMandatory` tinyint(4) NOT NULL DEFAULT '0',
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `clientLevelId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQ_CLIENTLEVELANDPROPGROUP` (`clientLevelId`,`alias`),
  KEY `FK_7971dcad2bb3ed56364d5560f79` (`createdById`),
  KEY `FK_43f17392cae098890cec0227a0d` (`updatedById`),
  CONSTRAINT `FK_43f17392cae098890cec0227a0d` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_5bb7b8a7a73169615831a87d303` FOREIGN KEY (`clientLevelId`) REFERENCES `client_level` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_7971dcad2bb3ed56364d5560f79` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_level_prop`
--

LOCK TABLES `client_level_prop` WRITE;
/*!40000 ALTER TABLE `client_level_prop` DISABLE KEYS */;
INSERT INTO `client_level_prop` VALUES ('0a99c1e0-63bf-4993-9b57-7439f0393b0f','2020-03-16 09:28:43.350339','2020-03-16 09:28:43.350339',1,0,'section alias','section alias','enter section alias',1,NULL,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'30e6b9f9-693e-4c14-8998-59f1d91e03a7'),('0f847401-5afa-4d17-8d26-8f666e53f237','2020-03-16 09:26:32.789605','2020-03-16 09:26:32.789605',1,0,'line alias','line alias','enter line alias',1,NULL,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'ffacbac2-9f77-437b-90cc-7dc77b08824a'),('a5d38561-34bb-4901-b065-f40660ad1388','2020-03-16 09:28:43.339447','2020-03-16 09:28:43.339447',1,0,'section name','section name','enter section name',1,NULL,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'30e6b9f9-693e-4c14-8998-59f1d91e03a7'),('b35cb348-ff33-447e-bd43-b117d6b2ae8a','2020-03-16 09:26:32.782187','2020-03-16 09:26:32.782187',1,0,'line name','line name','enter line name',1,NULL,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'ffacbac2-9f77-437b-90cc-7dc77b08824a'),('cd114e94-51ba-48c0-9966-6cd5cdd015d0','2020-03-16 09:22:11.838264','2020-03-16 09:22:11.838264',1,0,'plant alias','plant alias','enter plant alias',1,NULL,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'b3d00f84-a602-4785-9efb-54d4b1f75f97'),('f2b97a51-912b-4a91-b29b-1e0a25ed1871','2020-03-16 09:22:11.826888','2020-03-16 09:22:11.826888',1,0,'plant name','plant name','enter plant name',1,NULL,0,'ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'b3d00f84-a602-4785-9efb-54d4b1f75f97');
/*!40000 ALTER TABLE `client_level_prop` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:38:23
