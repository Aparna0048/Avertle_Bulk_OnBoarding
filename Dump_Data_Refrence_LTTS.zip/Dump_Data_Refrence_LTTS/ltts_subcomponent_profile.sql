-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subcomponent_profile`
--

DROP TABLE IF EXISTS `subcomponent_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcomponent_profile` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `subcomponentTypeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_53db0fb7fe873ceca9e838d775` (`alias`),
  KEY `FK_a242cdd2c1ef6009ac72e176f85` (`createdById`),
  KEY `FK_0291bdb0028caf70ce6178d2eea` (`updatedById`),
  KEY `FK_0bcdc7f6c818122cf2b6452fda0` (`subcomponentTypeId`),
  CONSTRAINT `FK_0291bdb0028caf70ce6178d2eea` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_0bcdc7f6c818122cf2b6452fda0` FOREIGN KEY (`subcomponentTypeId`) REFERENCES `subcomponent_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_a242cdd2c1ef6009ac72e176f85` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcomponent_profile`
--

LOCK TABLES `subcomponent_profile` WRITE;
/*!40000 ALTER TABLE `subcomponent_profile` DISABLE KEYS */;
INSERT INTO `subcomponent_profile` VALUES ('001a9c4e-3434-4e6f-b636-3980540fdcdc','2020-03-29 14:40:11.243717','2020-03-29 14:40:17.000000',1,1,'Conveyor_Subcomponent_Profile_2','Conveyor_Subcomponent_Profile_2','Conveyor_Subcomponent_Profile_2','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','8f4f4952-e332-4b3d-800f-3b0592ce791a'),('3522c452-b118-412b-8211-cc11db23d313','2020-03-26 05:06:08.924534','2020-03-27 08:51:06.000000',1,1,'Driller_Subcomponent_Profile_4','Driller_Subcomponent_Profile_4','Driller_Subcomponent_Profile_4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','ad2081e0-c1ce-4d70-a653-9328455392f4','8f4f4952-e332-4b3d-800f-3b0592ce791a'),('86415a8e-d754-4c76-8dd6-546d6b2b286e','2020-03-02 13:45:24.078135','2020-03-07 07:57:50.000000',1,0,'Induction_Subcomponent_Profile_3','Induction_Subcomponent_Profile_3','Induction_Subcomponent_Profile_3','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','cab977e1-5abc-4e93-94cb-e827219978f3'),('a716b80f-83de-4c61-8d3a-f8c6f77a4c1a','2020-03-09 10:15:01.384602','2020-03-09 10:15:01.384602',1,0,'Droplift-Subcomponent-Profile-1','Droplift-Subcomponent-Profile-1','Droplift-Subcomponent-Profile-1','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'e0f6ddd6-8755-4ada-bc64-e6ee0629b535'),('a7c97e76-5626-4b83-b87e-155d306dcda8','2020-03-30 06:49:38.339970','2020-03-30 06:49:44.000000',1,1,'Feed_Pump_Subcomponent_Profile_5','Feed_Pump_Subcomponent_Profile_5','Feed_Pump_Subcomponent_Profile_5','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','8f4f4952-e332-4b3d-800f-3b0592ce791a'),('dd8a503a-d822-4fc5-9292-3221506c9931','2020-03-27 17:03:26.161007','2020-03-27 17:03:42.000000',1,1,'Boiler_Subcomponent_Profile_6','Boiler_Subcomponent_Profile_6','Boiler_Subcomponent_Profile_6','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','5268b32e-639a-46e0-9202-234bcadf7f82'),('ff604170-e79c-43c2-9e95-ea66216c2c8a','2020-03-02 14:07:08.175939','2020-03-07 07:56:58.000000',1,0,'Conveyor_Subcomponent_Profile_1','Conveyor_Subcomponent_Profile_1','Conveyor_Subcomponent_Profile_1','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','8f4f4952-e332-4b3d-800f-3b0592ce791a');
/*!40000 ALTER TABLE `subcomponent_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:44:36
