-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gateway_onboarding_additional_detail`
--

DROP TABLE IF EXISTS `gateway_onboarding_additional_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gateway_onboarding_additional_detail` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `scalingFactor` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `gatewayProfileAdditionalInfoId` varchar(36) DEFAULT NULL,
  `sensorOnboardingId` varchar(36) DEFAULT NULL,
  `gatewayOnboardingId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_176889b433b6174cba903abbc5f` (`createdById`),
  KEY `FK_21da17b18be9da502e7befc2841` (`updatedById`),
  KEY `FK_f0895e4206b583fa8f3e0b93d9d` (`gatewayProfileAdditionalInfoId`),
  KEY `FK_536ef7826a2a66142598ad366b3` (`sensorOnboardingId`),
  KEY `FK_e8225ef3d7ba54771dd4fea9c9e` (`gatewayOnboardingId`),
  CONSTRAINT `FK_176889b433b6174cba903abbc5f` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_21da17b18be9da502e7befc2841` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_536ef7826a2a66142598ad366b3` FOREIGN KEY (`sensorOnboardingId`) REFERENCES `sensor_onboarding` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_e8225ef3d7ba54771dd4fea9c9e` FOREIGN KEY (`gatewayOnboardingId`) REFERENCES `gateway_onboarding` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_f0895e4206b583fa8f3e0b93d9d` FOREIGN KEY (`gatewayProfileAdditionalInfoId`) REFERENCES `gateway_profile_additional_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_onboarding_additional_detail`
--

LOCK TABLES `gateway_onboarding_additional_detail` WRITE;
/*!40000 ALTER TABLE `gateway_onboarding_additional_detail` DISABLE KEYS */;
INSERT INTO `gateway_onboarding_additional_detail` VALUES ('468bac87-0164-4d9d-bd41-7363d91c1090','2020-03-05 13:05:55.370102','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','df4cc791-c82a-4f1b-9753-6b52556fbff5','800c2a8e-9a66-4d84-b51e-7069de5350d9','5ba817bb-eece-41e8-af89-fdf3a6f7b041'),('62d819d6-277f-457f-99be-7252147cbed8','2020-03-05 13:05:55.386744','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','ce650006-5df1-490e-aef8-29a3587cc80e','5488a05b-3d49-4340-b484-9b89d8657dc4','5ba817bb-eece-41e8-af89-fdf3a6f7b041'),('6cb7e115-6409-4656-b212-1c22f15d5f95','2020-03-02 14:08:33.476954','2020-03-07 07:43:16.000000',1,0,'100','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','0ce77461-9ace-4182-89c5-96614c7023bb','5488a05b-3d49-4340-b484-9b89d8657dc4','6f3148a9-feb5-4e43-b376-bdebfe2e6070'),('75b70ac4-69b1-494c-8890-a2755d623a30','2020-03-24 05:59:08.885834','2020-03-24 05:59:08.885834',1,0,'100','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'d647a4e1-892d-43aa-8e78-aa9eb973b15c','412ed3d5-e579-4c67-b91c-b7ff6ab9247a','d34704de-1cea-4441-b6d7-e780fed3dd6b'),('7d22cfbd-cb29-4ae1-b2ab-056ed5801373','2020-03-05 13:05:55.388079','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','ed88a363-e176-460e-a8e1-dfe6aa093202','e05334e1-ed48-41ca-a0dc-708b01900af8','5ba817bb-eece-41e8-af89-fdf3a6f7b041'),('8ecd992d-2aa1-4739-b3d9-d8a9c116cce9','2020-03-02 13:47:18.239195','2020-03-02 13:47:18.239195',1,0,'100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'d647a4e1-892d-43aa-8e78-aa9eb973b15c','412ed3d5-e579-4c67-b91c-b7ff6ab9247a','4536c0d0-c7bc-4c8d-836d-5178c244d81b'),('a75cb031-5f9f-4681-a364-d0216e07fd45','2020-03-05 13:05:55.362630','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','d5f20d32-f93b-4b3a-bf02-e96e59e29958','4c0c65d7-8b3a-4e5a-bcaa-ba8636934a05','5ba817bb-eece-41e8-af89-fdf3a6f7b041'),('b93a1dc6-8cf6-4304-af6c-fb523b890bce','2020-03-05 13:05:55.368006','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','d68dd703-9cb3-4656-a7a0-2ee38222d598','d5c397b1-b36e-462c-ba35-84b402d6d3f5','5ba817bb-eece-41e8-af89-fdf3a6f7b041'),('cfed881b-8264-412a-85eb-dc351ff558b7','2020-03-05 13:05:55.385420','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','ea94e98f-39fb-4ff0-9f89-fd342b587363','412ed3d5-e579-4c67-b91c-b7ff6ab9247a','5ba817bb-eece-41e8-af89-fdf3a6f7b041'),('d26d4b50-7058-44a3-83c4-fcba916911a2','2020-03-27 17:31:13.068127','2020-03-27 17:31:13.068127',1,0,'5454','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'0ce77461-9ace-4182-89c5-96614c7023bb','5488a05b-3d49-4340-b484-9b89d8657dc4','4ddb77d3-2f6f-4c0b-ba8f-f581f5fd9281'),('d5d75ce4-3016-499f-ba24-1367e40e36d2','2020-03-05 13:05:55.385892','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','42731837-3c71-461d-8a5c-2cf36de107df','c64a7c40-5eb4-4346-9311-4f352f3b7a96','5ba817bb-eece-41e8-af89-fdf3a6f7b041'),('eb59690e-2dd8-41cd-8a16-fe1bed2152c7','2020-03-26 09:13:16.868511','2020-03-30 05:41:35.000000',1,0,'1111','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','d647a4e1-892d-43aa-8e78-aa9eb973b15c','412ed3d5-e579-4c67-b91c-b7ff6ab9247a','0495e781-2923-4f83-96bf-5292868458e4'),('f75a920d-f37d-4ae5-a3a1-ebaf360a814f','2020-03-05 13:05:55.386316','2020-03-09 10:01:53.000000',1,0,'20','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','8c52df7a-a833-41d4-8d89-52bd86045d42','a8ebd560-4944-4c60-be11-59a85a06952c','5ba817bb-eece-41e8-af89-fdf3a6f7b041');
/*!40000 ALTER TABLE `gateway_onboarding_additional_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:41:03
