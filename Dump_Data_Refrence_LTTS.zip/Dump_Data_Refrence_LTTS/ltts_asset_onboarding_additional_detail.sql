-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asset_onboarding_additional_detail`
--

DROP TABLE IF EXISTS `asset_onboarding_additional_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset_onboarding_additional_detail` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `assetProfileAdditionalInfoId` varchar(36) DEFAULT NULL,
  `subcomponentOnboardingAdditionalDetailId` varchar(36) DEFAULT NULL,
  `subcomponentOnboardingId` varchar(36) DEFAULT NULL,
  `assetOnboardingId` varchar(36) DEFAULT NULL,
  `axisTypeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `REL_3a6675a822a707de987c1fc0de` (`subcomponentOnboardingAdditionalDetailId`),
  KEY `FK_da3ac8ad22d31ae3ee6f0003d78` (`createdById`),
  KEY `FK_25e6afdbc2fd85a8fdb7801ddbe` (`updatedById`),
  KEY `FK_68e9a77064acb948f0f42e3dfb5` (`assetProfileAdditionalInfoId`),
  KEY `FK_67d940ef5358b16e40d7e59018a` (`subcomponentOnboardingId`),
  KEY `FK_256728f61752ec92f84fd80626d` (`assetOnboardingId`),
  KEY `FK_47f7f70195b59d1a675a6ae5061` (`axisTypeId`),
  CONSTRAINT `FK_256728f61752ec92f84fd80626d` FOREIGN KEY (`assetOnboardingId`) REFERENCES `asset_onboarding` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_25e6afdbc2fd85a8fdb7801ddbe` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_3a6675a822a707de987c1fc0de4` FOREIGN KEY (`subcomponentOnboardingAdditionalDetailId`) REFERENCES `subcomponent_onboarding_additional_detail` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_47f7f70195b59d1a675a6ae5061` FOREIGN KEY (`axisTypeId`) REFERENCES `axis_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_67d940ef5358b16e40d7e59018a` FOREIGN KEY (`subcomponentOnboardingId`) REFERENCES `subcomponent_onboarding` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_68e9a77064acb948f0f42e3dfb5` FOREIGN KEY (`assetProfileAdditionalInfoId`) REFERENCES `asset_profile_additional_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_da3ac8ad22d31ae3ee6f0003d78` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_onboarding_additional_detail`
--

LOCK TABLES `asset_onboarding_additional_detail` WRITE;
/*!40000 ALTER TABLE `asset_onboarding_additional_detail` DISABLE KEYS */;
INSERT INTO `asset_onboarding_additional_detail` VALUES ('137f0b00-5073-4ec9-8edb-47ad47856df6','2020-03-26 08:56:48.623143','2020-03-26 13:26:06.000000',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','80146cee-9e45-4394-8dc3-bdf581d47bca','3d509372-10cb-4171-9117-ac7e3e0be3f7','f7a0c4f8-c95e-43d3-8149-96bd8a3038ea','768988a6-162f-42e9-a4d5-23138c385337','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('141dd418-a23b-439b-888d-f005dfba0cb4','2020-03-26 11:36:10.403614','2020-03-26 11:36:10.403614',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'80146cee-9e45-4394-8dc3-bdf581d47bca','4b40e97d-045e-44d9-b734-513561d99cb5','ba6f547c-8e30-473f-8655-31c423a410d8','e232d85d-573e-4557-a5ae-45e2fb93d7c1','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('24b07d8a-7ef4-4108-9680-5a62e4a96693','2020-03-26 11:43:01.291732','2020-03-26 11:43:01.291732',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'342880b9-951a-4bce-b570-4ac49590623e','be7c32e1-922a-4b12-9b07-dd78d1d0355e','ba614ac2-6281-4a7c-a7ca-d3031c8be089','230d38ae-a6d4-4efb-8c7d-906be52ca00a','baf18457-a95c-4f80-b053-6adaccfd1cbf'),('3ce1e12f-60e4-4758-8a9f-f4f3ebbf28f9','2020-03-02 13:49:02.636406','2020-03-30 05:41:59.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','af5eae99-ca60-446c-996d-9fa7a7887ff7','a3541817-363b-4b6b-9d3e-c2e219ec923a','74f74cdc-439e-40c6-a0ee-027553b57a81','a86cf149-2a7d-45a3-8727-ea97d3b85ed5','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('4282e636-b31d-4194-bb55-e5d95fce0520','2020-03-26 12:42:48.707980','2020-03-26 13:24:23.000000',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','80146cee-9e45-4394-8dc3-bdf581d47bca','40c32fde-75ea-4d67-87f7-28ce61b94263','ba614ac2-6281-4a7c-a7ca-d3031c8be089','3c1fba72-9703-4aff-ae99-33737be7c941','81d848dc-1333-4b9f-b944-5ebfd640d57a'),('49b31eb2-dbaf-4a17-a0c1-117f290069f1','2020-03-06 08:05:13.281596','2020-03-26 13:26:30.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','80146cee-9e45-4394-8dc3-bdf581d47bca','c70a076b-411d-406b-935f-fe8fe4f87716','0df304f4-f5f7-47d8-8178-6c643572a945','cfe0f31b-8c9f-4c31-a711-a2ff0a601476','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('8e97d210-caf3-4e1b-baad-f10b693d4aaf','2020-03-26 13:20:36.523147','2020-03-26 13:26:15.000000',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','80146cee-9e45-4394-8dc3-bdf581d47bca','b064588c-2501-4892-a732-5b85e0b11b76','ba614ac2-6281-4a7c-a7ca-d3031c8be089','7fb3478e-2f79-447d-b100-989f1ba6ddff','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('9ea1d7f7-acb9-44eb-92fc-2a0a31033875','2020-03-02 14:09:37.103268','2020-03-26 13:25:46.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','80146cee-9e45-4394-8dc3-bdf581d47bca','dae35001-0757-4714-bc2f-c96eb719b7af','34a82dd3-4c79-4da1-a629-d34e25234a6f','20388726-b652-448d-bd79-fea8aa83bfdf','06bb8d8d-6d13-45c3-9a77-2b5d48838acf'),('c2346921-3709-4e12-93e7-06b7fc20e31e','2020-03-06 08:06:32.091699','2020-03-26 13:23:30.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','80146cee-9e45-4394-8dc3-bdf581d47bca','a848d8bf-7d6c-4bf6-aca4-5027e779e32d','6c784119-a27a-442e-8d8e-a14c4856ed7e','7c8d2dd7-a720-4df8-bb17-3c1d13af1a07','81d848dc-1333-4b9f-b944-5ebfd640d57a'),('fb77c6a2-e4a6-4f10-863a-d3899e6e856d','2020-03-26 08:51:14.046637','2020-03-26 08:51:14.046637',1,0,'b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'80146cee-9e45-4394-8dc3-bdf581d47bca','123a12e5-1fa7-4d37-82ac-ac20f25a66ff','011e32dd-fec3-4847-8aeb-37e75ac3d113','78e3f11e-eadb-4ef0-b6e5-194bc16399cf','f2cec923-1222-472c-9454-e1d68fdf7e14'),('fd73eee1-e921-4779-ac00-2bee18a3a1b4','2020-03-12 07:49:35.123441','2020-03-26 13:24:16.000000',1,0,'ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','80146cee-9e45-4394-8dc3-bdf581d47bca','f2e39e32-69c7-4036-96ba-72e3f2e30a00','ba614ac2-6281-4a7c-a7ca-d3031c8be089','51d6ebae-9762-4a83-b1a1-a82060b07749','737d1f2c-9628-4525-ae51-0ada94e6be35');
/*!40000 ALTER TABLE `asset_onboarding_additional_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:37:57
