-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gateway_profile`
--

DROP TABLE IF EXISTS `gateway_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gateway_profile` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_0b4cfb2e120138f04c40bfe367` (`alias`),
  KEY `FK_00e43a5d6c953089a18a406bba2` (`createdById`),
  KEY `FK_7ac035ab2e015f192a4159bab2e` (`updatedById`),
  CONSTRAINT `FK_00e43a5d6c953089a18a406bba2` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_7ac035ab2e015f192a4159bab2e` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gateway_profile`
--

LOCK TABLES `gateway_profile` WRITE;
/*!40000 ALTER TABLE `gateway_profile` DISABLE KEYS */;
INSERT INTO `gateway_profile` VALUES ('000f5117-ac8f-458d-b703-0370b111fe09','2020-03-02 13:45:50.593773','2020-03-24 11:37:03.000000',1,0,'Gateway-Profile-1','Gateway-Profile-1','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL),('711f5f91-491d-4436-be75-ac7f4f251b2a','2020-03-02 14:07:31.488726','2020-03-29 14:39:33.000000',1,1,'Gateway-Profile-2','Gateway-Profile-2','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL),('88202181-8be4-49e8-bd09-a1a8b2f462ea','2020-03-05 12:50:38.325785','2020-03-05 12:50:38.325785',1,0,'Gateway-Profile-3','Gateway-Profile-3','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('a5e69726-f2e2-407f-acad-06b4669e48a2','2020-03-27 14:35:32.283915','2020-03-27 14:35:40.000000',1,1,'gateway-profile-5','gateway-profile-5','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL),('b3e00453-2605-4e7c-8bed-10aac2f179da','2020-03-05 12:52:11.559125','2020-03-27 08:51:15.000000',1,1,'Gateway-Profile-4','Gateway-Profile-4','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('e0b232bf-1dfc-4efb-a19c-5da26cf11f59','2020-03-27 17:07:43.935022','2020-03-27 17:07:52.000000',1,1,'Gateway-Profile-6','Gateway-Profile-6','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL);
/*!40000 ALTER TABLE `gateway_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:39:08
