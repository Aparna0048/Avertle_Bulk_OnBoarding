-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sensor_onboarding`
--

DROP TABLE IF EXISTS `sensor_onboarding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensor_onboarding` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `serialNo` varchar(255) NOT NULL,
  `calibFactor` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `sensorTypeId` varchar(36) DEFAULT NULL,
  `makeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_2c4584645f30d2f18097397936` (`alias`),
  UNIQUE KEY `IDX_89406a89e23ca62780185e4939` (`serialNo`),
  KEY `FK_5d9d0c9e541456a842e7c005fe0` (`createdById`),
  KEY `FK_6b59b67e7dbdd558ded10086bb0` (`updatedById`),
  KEY `FK_25d3ded9b326b7e5f224e5f06ca` (`sensorTypeId`),
  KEY `FK_6e7a8451a9a898b1781cdf0bef2` (`makeId`),
  CONSTRAINT `FK_25d3ded9b326b7e5f224e5f06ca` FOREIGN KEY (`sensorTypeId`) REFERENCES `sensor_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_5d9d0c9e541456a842e7c005fe0` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_6b59b67e7dbdd558ded10086bb0` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_6e7a8451a9a898b1781cdf0bef2` FOREIGN KEY (`makeId`) REFERENCES `make` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_onboarding`
--

LOCK TABLES `sensor_onboarding` WRITE;
/*!40000 ALTER TABLE `sensor_onboarding` DISABLE KEYS */;
INSERT INTO `sensor_onboarding` VALUES ('412ed3d5-e579-4c67-b91c-b7ff6ab9247a','2020-03-02 13:46:36.456968','2020-03-30 05:41:27.000000',1,0,'sensoronboard-1','sensoronboard-1','SENSORONBOARD-1','100','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','31d85ed9-7217-43ca-96cb-7e2e8e113875','258c4fef-b491-4c3e-bb67-3bf5656eb21f'),('4c0c65d7-8b3a-4e5a-bcaa-ba8636934a05','2020-03-05 13:03:32.785006','2020-03-05 13:03:32.785006',1,0,'sensoronboard-6','sensoronboard-6','SENSORONBOARD-6','100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'6f6691f6-2f1a-4bee-a80a-1785226a239d','258c4fef-b491-4c3e-bb67-3bf5656eb21f'),('5488a05b-3d49-4340-b484-9b89d8657dc4','2020-03-02 14:08:01.691312','2020-03-02 14:08:01.691312',1,0,'sensoronboard-2','sensoronboard-2','SENSORONBOARD-2','100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'7accf643-0d94-4676-b232-0b033e01c69f','258c4fef-b491-4c3e-bb67-3bf5656eb21f'),('800c2a8e-9a66-4d84-b51e-7069de5350d9','2020-03-05 12:57:44.977130','2020-03-05 12:57:44.977130',1,0,'ultrasonic sensoronboard','ultrasonic sensoronboard','SENSORONBOARD-3','100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'1f73c9cc-f196-4b01-9fa5-bdeb54fc060a','258c4fef-b491-4c3e-bb67-3bf5656eb21f'),('a8ebd560-4944-4c60-be11-59a85a06952c','2020-03-05 13:04:03.696581','2020-03-05 13:04:03.696581',1,0,'sensoronboard-7','sensoronboard-7','SENSORONBOARD-7','100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'5f99800d-6d35-408d-a863-5aff811a3ce7','258c4fef-b491-4c3e-bb67-3bf5656eb21f'),('c64a7c40-5eb4-4346-9311-4f352f3b7a96','2020-03-05 13:04:39.725145','2020-03-05 13:04:39.725145',1,0,'sensoronboard-8','sensoronboard-8','SENSORONBOARD-8','100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'6bfc8412-c92a-4f0a-8eb3-49ff79b3a3f4','258c4fef-b491-4c3e-bb67-3bf5656eb21f'),('d5c397b1-b36e-462c-ba35-84b402d6d3f5','2020-03-05 13:02:25.035583','2020-03-05 13:02:25.035583',1,0,'sensoronboard-4','sensoronboard-4','SENSORONBOARD-4','100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'09712a55-6763-4c75-b7b0-39197a84a17f','258c4fef-b491-4c3e-bb67-3bf5656eb21f'),('e05334e1-ed48-41ca-a0dc-708b01900af8','2020-03-05 13:03:01.675530','2020-03-05 13:03:01.675530',1,0,'sensoronboard-5','sensoronboard-5','SENSORONBOARD-5','100','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'5abd2b59-3327-4c6e-8d94-bedf7368ef81','258c4fef-b491-4c3e-bb67-3bf5656eb21f');
/*!40000 ALTER TABLE `sensor_onboarding` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:40:38
