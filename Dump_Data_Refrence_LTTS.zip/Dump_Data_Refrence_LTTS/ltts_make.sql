-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `make`
--

DROP TABLE IF EXISTS `make`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `make` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `makeTypeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_47df74c04f384bb41c18e2711f` (`alias`),
  KEY `FK_10bb473591bf6b9516a31aa29d0` (`createdById`),
  KEY `FK_65a9cde00d0078e851e9a7b0463` (`updatedById`),
  KEY `FK_ab809c94f86497abb99eceb385a` (`makeTypeId`),
  CONSTRAINT `FK_10bb473591bf6b9516a31aa29d0` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_65a9cde00d0078e851e9a7b0463` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ab809c94f86497abb99eceb385a` FOREIGN KEY (`makeTypeId`) REFERENCES `make_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `make`
--

LOCK TABLES `make` WRITE;
/*!40000 ALTER TABLE `make` DISABLE KEYS */;
INSERT INTO `make` VALUES ('258c4fef-b491-4c3e-bb67-3bf5656eb21f','2020-03-23 14:18:57.745049','2020-03-23 14:18:57.745049',1,0,'cd','cd','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'964355e3-cfdf-44da-aea8-98d82dfa6bd0'),('3fec10de-5293-4c28-9cb4-350f27bc7bdf','2020-03-02 13:33:49.426317','2020-03-02 13:33:49.426317',1,0,'ltts','ltts','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'96a2d8bc-4337-41f8-93c8-c7de31b83c29'),('488be755-528f-4b80-820c-bd3e0b30de08','2020-03-26 07:48:08.841917','2020-03-26 07:48:08.841917',1,0,'pyromation-asset','pyromation-asset','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'67e2f703-9aec-4b23-9980-f2ae7d8f1b4e'),('71d2fe7f-5197-4b16-9bb8-eaab647b2913','2020-03-24 09:55:02.367561','2020-03-24 09:55:02.367561',1,0,'testing','testing','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,NULL),('d13b66d6-dcd2-4eff-84ca-e1633c4b2e18','2020-03-26 07:48:56.271704','2020-03-26 07:48:56.271704',1,0,'pyromation-subcomponent','pyromation-subcomponent','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'982f68fc-9e63-491e-b96e-b0146d4e7996');
/*!40000 ALTER TABLE `make` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:39:53
