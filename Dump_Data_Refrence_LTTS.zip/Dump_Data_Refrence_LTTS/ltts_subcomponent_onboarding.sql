-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subcomponent_onboarding`
--

DROP TABLE IF EXISTS `subcomponent_onboarding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcomponent_onboarding` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `serialNo` varchar(255) NOT NULL,
  `mgfDate` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `subcomponentProfileId` varchar(36) DEFAULT NULL,
  `makeId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_d92a7d765ecb3dd097aa08bc13` (`alias`),
  UNIQUE KEY `IDX_d84786bfac3048ca1e9a23e4e7` (`serialNo`),
  KEY `FK_96ea5a24a47e0b6213cd024fbbc` (`createdById`),
  KEY `FK_9c76d696d298200c37119aab588` (`updatedById`),
  KEY `FK_fb762962320450f6516ed3681f6` (`subcomponentProfileId`),
  KEY `FK_e249c0bf18e35a4cc4d625f5016` (`makeId`),
  CONSTRAINT `FK_96ea5a24a47e0b6213cd024fbbc` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_9c76d696d298200c37119aab588` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_e249c0bf18e35a4cc4d625f5016` FOREIGN KEY (`makeId`) REFERENCES `make` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_fb762962320450f6516ed3681f6` FOREIGN KEY (`subcomponentProfileId`) REFERENCES `subcomponent_profile` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcomponent_onboarding`
--

LOCK TABLES `subcomponent_onboarding` WRITE;
/*!40000 ALTER TABLE `subcomponent_onboarding` DISABLE KEYS */;
INSERT INTO `subcomponent_onboarding` VALUES ('011e32dd-fec3-4847-8aeb-37e75ac3d113','2020-03-09 10:35:56.064563','2020-03-26 09:15:08.000000',1,0,'induction_subcomponent_onboard_2','induction_subcomponent_onboard_2','Induction_Subcomponent_Onboard_2','09/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','86415a8e-d754-4c76-8dd6-546d6b2b286e','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18'),('0df304f4-f5f7-47d8-8178-6c643572a945','2020-03-05 13:12:23.103791','2020-03-07 07:45:36.000000',1,0,'conveyor_subcomponent_onboard_3','conveyor_subcomponent_onboard_3','CONVEYOR_SUBCOMPONENT_ONBOARD_3','31/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','ff604170-e79c-43c2-9e95-ea66216c2c8a','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18'),('34a82dd3-4c79-4da1-a629-d34e25234a6f','2020-03-02 14:09:04.655874','2020-03-07 07:44:54.000000',1,0,'precipitator_subcomponent_onboard_2','precipitator_subcomponent_onboard_2','PRECIPITATOR_SUBCOMPONENT_ONBOARD_2','02/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','ff604170-e79c-43c2-9e95-ea66216c2c8a','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18'),('6c784119-a27a-442e-8d8e-a14c4856ed7e','2020-03-05 13:11:26.193701','2020-03-07 07:46:04.000000',1,0,'condensor_subcomponent_onboard_4','condensor_subcomponent_onboard_4','CONDENSOR_SUBCOMPONENT_ONBOARD_4','05/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','ff604170-e79c-43c2-9e95-ea66216c2c8a','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18'),('74f74cdc-439e-40c6-a0ee-027553b57a81','2020-03-02 13:48:26.123269','2020-03-07 07:46:29.000000',1,0,'boiler-subcomponent_onboard_1','boiler_subcomponent_onboard_1','BOILER_SUBCOMPONENT_ONBOARD_1','02/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','86415a8e-d754-4c76-8dd6-546d6b2b286e','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18'),('ba614ac2-6281-4a7c-a7ca-d3031c8be089','2020-03-09 10:16:14.505201','2020-03-09 10:16:14.505201',1,0,'drop-lift-subcomponent-onboard-1','drop-lift-subcomponent-onboard-1','Drop-Lift-Subcomponent-Onboard-1','09/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'a716b80f-83de-4c61-8d3a-f8c6f77a4c1a','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18'),('ba6f547c-8e30-473f-8655-31c423a410d8','2020-03-12 10:43:32.142184','2020-03-12 10:43:32.142184',1,0,'induction_subcomponent_onboard_3','induction_subcomponent_onboard_3','Induction_Subcomponent_Onboard_3','12/03/2020','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'86415a8e-d754-4c76-8dd6-546d6b2b286e','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18'),('c42d6e83-8e61-4891-ac2a-2d69bb438f25','2020-03-26 09:14:21.727993','2020-03-26 09:14:21.727993',1,0,'pump_subcomponent_onboard_5','pump_subcomponent_onboard_5','pump_subcomponent_onboard_5','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL,'3522c452-b118-412b-8211-cc11db23d313','3fec10de-5293-4c28-9cb4-350f27bc7bdf'),('f7a0c4f8-c95e-43d3-8149-96bd8a3038ea','2020-03-26 08:52:37.316601','2020-03-26 09:14:55.000000',1,0,'drill_subcomponent_onboard_6','drill_subcomponent_onboard_6','drill_subcomponent_onboard_6','26/03/2020','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','3522c452-b118-412b-8211-cc11db23d313','d13b66d6-dcd2-4eff-84ca-e1633c4b2e18');
/*!40000 ALTER TABLE `subcomponent_onboarding` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:42:22
