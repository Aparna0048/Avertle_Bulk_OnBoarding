-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `widget_additional_detail`
--

DROP TABLE IF EXISTS `widget_additional_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widget_additional_detail` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `widgetTitle` varchar(255) DEFAULT NULL,
  `component` varchar(255) DEFAULT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `resizable` tinyint(4) DEFAULT NULL,
  `dragHelper` json DEFAULT NULL,
  `gridsterData` json DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `widgetParamterName` json DEFAULT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  `widgetId` varchar(36) DEFAULT NULL,
  `componentRef` varchar(255) DEFAULT NULL,
  `dragAndDrop` tinyint(4) DEFAULT NULL,
  `minWidth` int(11) DEFAULT NULL,
  `minHeight` int(11) DEFAULT NULL,
  `w` int(11) DEFAULT NULL,
  `h` int(11) DEFAULT NULL,
  `wsm` int(11) DEFAULT NULL,
  `hsm` int(11) DEFAULT NULL,
  `wMd` int(11) DEFAULT NULL,
  `hMd` int(11) DEFAULT NULL,
  `wLg` int(11) DEFAULT NULL,
  `hLg` int(11) DEFAULT NULL,
  `wXl` int(11) DEFAULT NULL,
  `hXl` int(11) DEFAULT NULL,
  `maxWidth` int(11) DEFAULT NULL,
  `maxHeight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_f9f22569dbe121481af2a05d611` (`createdById`),
  KEY `FK_9e09b0da3cb6facdfed3d33e32b` (`updatedById`),
  KEY `FK_fec52dc2cf3617dc00ab58812c4` (`widgetId`),
  CONSTRAINT `FK_9e09b0da3cb6facdfed3d33e32b` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_f9f22569dbe121481af2a05d611` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_fec52dc2cf3617dc00ab58812c4` FOREIGN KEY (`widgetId`) REFERENCES `widget` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget_additional_detail`
--

LOCK TABLES `widget_additional_detail` WRITE;
/*!40000 ALTER TABLE `widget_additional_detail` DISABLE KEYS */;
INSERT INTO `widget_additional_detail` VALUES ('0c4335da-fdec-45c1-8d6e-ca0e3fb99dd2','2020-01-29 16:22:43.630100','2020-01-29 16:22:43.630100',1,0,'Asset Details','AssetInfoComponent',NULL,1,'{\"helper\": true}','{}',NULL,'{}',NULL,NULL,'3184348c-dc86-43b8-b1df-de357d13ac06',NULL,0,5,4,5,4,5,4,4,3,4,3,5,4,14,14),('14c08b9d-5cf8-4772-9f6c-9386331df91f','2020-01-29 16:30:51.004326','2020-01-29 16:30:51.004326',1,0,'Sensor Map','SensorMapComponent',NULL,1,'{\"helper\": true}','{}',NULL,'{}',NULL,NULL,'8d91c070-9394-49d7-a02c-966ae59db107',NULL,0,5,4,5,4,5,4,4,3,4,3,5,4,14,14),('44d93704-b65c-4cf2-8009-aa4e3cd96b0e','2020-03-12 11:07:00.592560','2020-03-12 11:07:00.592560',1,0,'NameplateComponent','NameplateComponent',NULL,1,'{\"helper\": true}','{}',NULL,'{}','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL,'27f6365b-c4bd-41ef-8eea-c1207110479d',NULL,1,5,4,5,4,5,4,4,3,4,3,5,4,14,14),('5','2020-01-29 13:06:25.199400','2020-01-29 13:06:25.199400',1,0,'event logs','EventLogsWidgetComponent',NULL,1,'{\"helper\": true}','{}',NULL,'{}',NULL,NULL,'a66fd94e-7c51-48cb-b06f-f0ec03a1d556',NULL,0,5,4,5,4,5,4,4,3,4,3,5,4,14,14),('6','2020-01-29 13:09:19.189535','2020-01-29 13:09:19.189535',1,0,'Watch List','WatchListComponent',NULL,1,'{\"helper\": true}','{}',NULL,'{\"apiInterval\": 6000}',NULL,NULL,'bc7aa231-4ea9-4f1c-b633-28e726d72a67',NULL,1,5,4,5,4,5,4,4,3,4,3,5,4,14,14),('77c3e2f3-9f21-4aab-a504-317d2f0a05df','2020-02-05 11:26:21.488591','2020-02-05 11:26:21.488591',1,0,'Watch List','WatchListComponent','image',1,'{\"helper\": true}','{}','{}','{\"apiInterval\": 6}',NULL,'bf2beb7b-bfe0-4df6-9d18-61fe47898163','bc7aa231-4ea9-4f1c-b633-28e726d72a67',NULL,1,5,4,5,4,5,4,4,3,4,3,5,4,14,14),('91373382-03c1-4364-9563-24f1d86e36a6','2020-02-05 11:51:44.818285','2020-02-05 11:51:44.818285',1,0,'ewe','MapWidgetComponent','frc',1,'{\"helper\": true}','{}','{}','{\"apiInterval\": 45}',NULL,'bf2beb7b-bfe0-4df6-9d18-61fe47898163','bc7aa231-4ea9-4f1c-b633-28e726d72a67',NULL,1,5,4,5,4,5,4,4,3,4,3,5,4,14,14),('bc81d89f-981c-4c22-b843-0026001214b6','2020-02-05 11:32:21.196442','2020-02-05 11:32:21.196442',1,0,'Watch List','WatchListComponent','test-image',1,'{\"helper\": true}','{}','{}','{\"apiInterval\": 40}',NULL,'bf2beb7b-bfe0-4df6-9d18-61fe47898163','bc7aa231-4ea9-4f1c-b633-28e726d72a67',NULL,1,5,4,15,2,5,4,4,3,4,3,5,4,14,14),('c140cf6c-b979-4ed1-9e02-1f1f1bd2cbb1','2020-03-18 15:02:41.347233','2020-03-18 15:13:51.000000',1,0,'Singleparameter Widget','SingleParameterComponent',NULL,1,'{\"helper\": true}','{}',NULL,'{}','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4','1b17be7e-4553-4c64-8106-942420ac3182',NULL,1,5,5,5,4,5,4,4,3,4,3,5,4,16,16);
/*!40000 ALTER TABLE `widget_additional_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:38:41
