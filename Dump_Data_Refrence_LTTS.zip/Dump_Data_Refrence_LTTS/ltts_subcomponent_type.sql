-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subcomponent_type`
--

DROP TABLE IF EXISTS `subcomponent_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcomponent_type` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_4a8c4b351a61b307617c0a3a6c` (`alias`),
  KEY `FK_bb1237dee44e10a39cc902e7611` (`createdById`),
  KEY `FK_8ca24537b6e966ebba5e2451502` (`updatedById`),
  CONSTRAINT `FK_8ca24537b6e966ebba5e2451502` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_bb1237dee44e10a39cc902e7611` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcomponent_type`
--

LOCK TABLES `subcomponent_type` WRITE;
/*!40000 ALTER TABLE `subcomponent_type` DISABLE KEYS */;
INSERT INTO `subcomponent_type` VALUES ('2494af44-8c53-49de-b3af-dfdb672f0a89','2020-03-05 06:27:13.956018','2020-03-05 06:27:13.956018',1,0,'subcomponent-type-1','subcomponent-type-1','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('25ab2939-7fd2-4888-8ffc-69ca99a73ff3','2020-03-05 06:27:52.663302','2020-03-05 06:27:52.663302',1,0,'subcomponent-type-4','subcomponent-type-4','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('5268b32e-639a-46e0-9202-234bcadf7f82','2020-03-24 13:56:18.986393','2020-03-24 13:56:18.986393',1,0,'driller-type','driller-type','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL),('7e4b7bb3-d15d-4ea1-a4ab-ab93f26e300f','2020-03-27 16:33:43.436823','2020-03-27 16:33:52.000000',1,1,'ryryryryr','yryryry','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc'),('8f4f4952-e332-4b3d-800f-3b0592ce791a','2020-03-02 14:05:35.625249','2020-03-02 14:05:35.625249',1,0,'conveyor-type','conveyor-type','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('b4e267e0-994e-46d6-a3be-81331c3ee3cb','2020-03-05 06:27:41.357703','2020-03-05 06:27:41.357703',1,0,'subcomponent-type-3','subcomponent-type-3','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('b74deac0-9f44-49df-93e6-b722b2f008f9','2020-03-05 06:27:27.983837','2020-03-05 06:27:27.983837',1,0,'subcomponent-type-2','subcomponent-type-2','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('c4db9aa1-5171-4b2e-8f14-7168b160efd0','2020-03-05 06:19:58.604176','2020-03-05 06:19:58.604176',1,0,'motor-type','motor-type','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('cab977e1-5abc-4e93-94cb-e827219978f3','2020-03-02 13:34:31.164850','2020-03-02 13:34:31.164850',1,0,'induction-type','induction-type','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('e0f6ddd6-8755-4ada-bc64-e6ee0629b535','2020-03-05 06:25:19.774241','2020-03-05 06:25:19.774241',1,0,'droplifts-type','droplifts-type','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('f9d73d7f-3398-46ca-846e-da5574fc59f6','2020-03-05 06:28:06.746541','2020-03-05 06:28:06.746541',1,0,'subcomponent-type-5','subcomponent-type-5','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL);
/*!40000 ALTER TABLE `subcomponent_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:44:53
