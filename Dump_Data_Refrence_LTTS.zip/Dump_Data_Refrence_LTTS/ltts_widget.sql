-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `widget`
--

DROP TABLE IF EXISTS `widget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widget` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_7c204862b4d9a934544c1f937eb` (`createdById`),
  KEY `FK_e165ce420fa153d794ac95ac69a` (`updatedById`),
  CONSTRAINT `FK_7c204862b4d9a934544c1f937eb` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_e165ce420fa153d794ac95ac69a` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widget`
--

LOCK TABLES `widget` WRITE;
/*!40000 ALTER TABLE `widget` DISABLE KEYS */;
INSERT INTO `widget` VALUES ('1b17be7e-4553-4c64-8106-942420ac3182','2020-03-18 15:02:41.326332','2020-03-18 15:13:51.000000',1,0,'Singleparameter Widget','Singleparameter Widget','ad2081e0-c1ce-4d70-a653-9328455392f4','ad2081e0-c1ce-4d70-a653-9328455392f4'),('27f6365b-c4bd-41ef-8eea-c1207110479d','2020-03-12 11:07:00.580104','2020-03-12 11:07:00.580104',1,0,'Nameplate Widget','Nameplate Widget','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('3184348c-dc86-43b8-b1df-de357d13ac06','2020-01-29 16:22:43.620128','2020-01-29 16:22:43.620128',1,0,'Asset Details','Asset Details',NULL,NULL),('8d91c070-9394-49d7-a02c-966ae59db107','2020-01-29 16:30:51.001104','2020-01-29 16:30:51.001104',1,0,'Sensor List','Sensor List',NULL,NULL),('a66fd94e-7c51-48cb-b06f-f0ec03a1d556','2020-01-29 13:06:25.183039','2020-01-29 13:13:57.000000',1,0,'Event Logs','Event Logs',NULL,'bf2beb7b-bfe0-4df6-9d18-61fe47898163'),('bc7aa231-4ea9-4f1c-b633-28e726d72a67','2020-01-29 13:09:19.146839','2020-02-05 11:32:21.000000',1,0,'Watch List','Watch List',NULL,'bf2beb7b-bfe0-4df6-9d18-61fe47898163');
/*!40000 ALTER TABLE `widget` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:42:13
