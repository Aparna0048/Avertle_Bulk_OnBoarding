-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ltts
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sensor_type`
--

DROP TABLE IF EXISTS `sensor_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sensor_type` (
  `id` varchar(36) NOT NULL,
  `createdAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `createdById` varchar(36) DEFAULT NULL,
  `updatedById` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_020d085700ed058a4fcea7060f` (`alias`),
  KEY `FK_2a33e6d9d19e89e89ff7908c720` (`createdById`),
  KEY `FK_8d1e86411c8a7ec200f033bf7e7` (`updatedById`),
  CONSTRAINT `FK_2a33e6d9d19e89e89ff7908c720` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_8d1e86411c8a7ec200f033bf7e7` FOREIGN KEY (`updatedById`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sensor_type`
--

LOCK TABLES `sensor_type` WRITE;
/*!40000 ALTER TABLE `sensor_type` DISABLE KEYS */;
INSERT INTO `sensor_type` VALUES ('09712a55-6763-4c75-b7b0-39197a84a17f','2020-03-05 05:36:23.945606','2020-03-05 05:36:23.945606',1,0,'pressure','pressure','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('1f73c9cc-f196-4b01-9fa5-bdeb54fc060a','2020-03-05 05:36:43.097663','2020-03-05 05:36:43.097663',1,0,'ultrasonic','ultrasonic','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('31d85ed9-7217-43ca-96cb-7e2e8e113875','2020-03-02 12:49:06.016313','2020-03-02 12:49:06.016313',1,0,'temperature','temperature','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('57750ae2-b82f-438c-9932-8dfa472a7730','2020-03-27 08:48:50.246895','2020-03-27 14:08:07.000000',1,1,'load cell','load-cell','ad2081e0-c1ce-4d70-a653-9328455392f4','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc'),('5abd2b59-3327-4c6e-8d94-bedf7368ef81','2020-03-05 05:36:03.477523','2020-03-05 05:36:03.477523',1,0,'motion','motion','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('5cb29717-706e-4625-a1c1-3201ce81d566','2020-03-30 07:15:00.056440','2020-03-30 07:15:00.056440',1,0,'testingdata','testingdata','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL),('5f99800d-6d35-408d-a863-5aff811a3ce7','2020-03-05 05:35:44.821196','2020-03-05 05:35:44.821196',1,0,'current','current','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('6b2a3e55-5268-4b4d-8c80-f6c7af868158','2020-03-24 09:51:24.818043','2020-03-24 09:51:24.818043',1,0,'ultrasonic testing','ultrasonic testing','b5d0202a-ab3a-4ee7-9b80-55e9fad0a2bc',NULL),('6bfc8412-c92a-4f0a-8eb3-49ff79b3a3f4','2020-03-05 05:35:25.205992','2020-03-05 05:35:25.205992',1,0,'vibration','vibration','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('6f6691f6-2f1a-4bee-a80a-1785226a239d','2020-03-05 05:34:47.444681','2020-03-05 05:34:47.444681',1,0,'ignition','ignition','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('7842b5a2-45a0-4ca9-b723-78ae46b050f6','2020-03-07 10:04:45.727005','2020-03-07 10:04:45.727005',1,0,'infrared sensor','infrared sensor','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL),('7accf643-0d94-4676-b232-0b033e01c69f','2020-03-02 14:03:32.507756','2020-03-02 14:03:32.507756',1,0,'voltage','voltage','ad2081e0-c1ce-4d70-a653-9328455392f4',NULL);
/*!40000 ALTER TABLE `sensor_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 13:38:59
